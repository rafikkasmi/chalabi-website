<?php $__env->startSection('title', 'Orders'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
   <div class="row">
      <div class="col-md-12">
         <div class="card">
               <div class="card-header">
                  <h3 class="text-center">
                     Table Des Prix
                  </h4>
               </div>
               <div class="card-body">
                  <form action="<?php echo e(url('update-prices')); ?>" method="POST" enctype="multipart/form-data">
                     <?php echo csrf_field(); ?>
                  <table class="table table-bordered text-center">
                     <thead>
                        <tr>
                           <th>Nom</th>
                           <th>De</th>
                           <th>Jusqu'a</th>
                           <th>Action</th>
                        </tr>
                     </thead>
                     <tbody>
                     

                        <?php $__currentLoopData = $prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <tr>
                              <td><?php echo e($price->name); ?></td>
                              <td><input type="number" name="priceFrom<?php echo e($price->id); ?>" class="form-control border p-2" value="<?php echo e($price->from); ?>"></td>
                              <td><input type="number" name="priceTo<?php echo e($price->id); ?>" class="form-control border p-2" value="<?php echo e($price->to); ?>"></td>
                              <td>
                                 <button type="submit" class="btn btn-primary">Modifier</button>
                              </td>
                           </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                     </tbody>
                  </table>
                     </form>

               </div>
            </div>
      </div>
   </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rafik/bijouterie/ecommerce/resources/views/admin/orders/index.blade.php ENDPATH**/ ?>