<footer class="footer py-4">
   <div class="container">
      <div class="row">
         <div class="col-md-12">
            <div class="copyright text-center">
               ©
               <script>
                  document.write(new Date().getFullYear())
               </script>,
               Made with <i class="fa fa-heart"></i> by
               <a href="https://www.creative-tim.com" class="font-weight-bold" target="_blank">Creative Tim</a>
               for a better web. <br/>
               ©
               <script>
                  document.write(new Date().getFullYear())
               </script>,
               Back-End Developer <a href="https://github.com/obaidash99" class="font-weight-bold" target="_blank">Obaida Shurbaji</a> <br/>
               <a href="https://www.creative-tim.com/license" class="font-weight-bold float-end" target="_blank">License</a>
            </div>
         </div>
      </div>
   </div>
</footer><?php /**PATH /home/rafik/bijouterie/ecommerce/resources/views/layouts/inc/adminfooter.blade.php ENDPATH**/ ?>