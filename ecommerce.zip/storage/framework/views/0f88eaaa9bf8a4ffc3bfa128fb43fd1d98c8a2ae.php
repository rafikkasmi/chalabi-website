<?php $__env->startSection('content'); ?>

<div class="card">
   <div class="card-header">
      <h3>Registered Users</h3>
      <hr>
   </div>

   <div class="card-body">
      <table class="table text-center table-bordered table-striped">
         <thead>
            <tr>
               <th>ID</th>
               <th>Name</th>
               <th>Email</th>
               <th>Phone Number</th>
               <th>Action</th>
            </tr>
         </thead>
         <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
               <td><?php echo e($user->id); ?></td>
               <td><?php echo e($user->name . " " . $user->lname); ?></td>
               <td><?php echo e($user->email); ?></td>
               <td><?php echo e($user->phone); ?></td>
               <td>
                  <a href="<?php echo e(url('view-user/' . $user->id)); ?>" class="btn btn-info">View</a>
               </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </tbody>
      </table>
   </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rafik/bijouterie/ecommerce/resources/views/admin/users/index.blade.php ENDPATH**/ ?>