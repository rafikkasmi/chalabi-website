<?php $__env->startSection('content'); ?>

<div class="col-md-12 column">
   <div class="card-header">
      <h3>Produits</h3>
      <hr>
   </div>

      <table class="table text-center table-bordered table-striped">
         <thead>
            <tr>
               <th>Nom</th>
               <th>Categorie</th>
               <th>Marque</th>
               <th>Original Price</th>
               <th>Selling Price</th>
               <th>Image</th>
               <th>Action</th>
            </tr>
         </thead>
         <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
               <td><?php echo e($item->name); ?></td>
               <td><?php echo e($item->category->name); ?></td>
               <td><?php echo e($item->brand); ?></td>
               <td><?php echo e($item->original_price); ?></td>
               <td><?php echo e($item->selling_price); ?></td>
               <td>
                  <img src="<?php echo e(asset('assets/uploads/products/' . $item->image)); ?>" class="cate-image" alt="img not found">
               </td>
               <td>
                  <a href="<?php echo e(url('edit-product/' . $item->id)); ?>" class="btn btn-info">Edit</a>
                  <a href="<?php echo e(url('delete-product/' . $item->id)); ?>" class="btn btn-danger">Delete</a>
               </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </tbody>
      </table>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rafik/bijouterie/ecommerce/resources/views/admin/product/index.blade.php ENDPATH**/ ?>