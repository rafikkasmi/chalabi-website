<?php $__env->startSection('content'); ?>

<div class="card">
   <div class="card-header">
      <h2>Modifier Marque</h2>
   </div>

   <div class="card-body">
      <form action="<?php echo e(url('update-brand/' . $brand->id)); ?>" method="POST">
         <?php echo csrf_field(); ?>
         <?php echo method_field('PUT'); ?>
      <div class="row">
            <div class="col-md-6 md-3">
               <label for="name">Nom</label>
               <input type="text" name="name" value="<?php echo e($brand->name); ?>" id="name" class="form-control border p-2">
            </div>
            <div class="col-md-12 mb-3">
               <button type="submit" class="btn btn-primary">Modifier</button>
            </div>
         </div>
      </form>
   </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rafik/bijouterie/ecommerce/resources/views/admin/brand/edit.blade.php ENDPATH**/ ?>