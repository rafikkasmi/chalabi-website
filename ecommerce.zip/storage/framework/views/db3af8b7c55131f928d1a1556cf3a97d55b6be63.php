<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">

   <!-- CSRF Token -->
   <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

   <title><?php echo e(config('app.name', 'Chalabi Store Admin Panel')); ?></title>

   <!-- Font Awesome Icons -->
   <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
   <!-- Material Icons -->
   <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">

   <!-- Styles -->
   <link href="<?php echo e(asset('admin/css/material-dashboard.css')); ?>" rel="stylesheet">
   <link href="<?php echo e(asset('admin/css/custom.css')); ?>" rel="stylesheet">
    <script src=" <?php echo e(asset('frontend/js/jquery-3.6.2.min.js')); ?>"></script>

   <link href="https://unpkg.com/filepond@^4/dist/filepond.css" rel="stylesheet" />
   <script src="https://unpkg.com/filepond@^4/dist/filepond.js"></script>
   <link
    href="https://unpkg.com/filepond-plugin-image-preview/dist/filepond-plugin-image-preview.css"
    rel="stylesheet"
/>

<!-- add before </body> -->
<script src="https://unpkg.com/filepond-plugin-image-preview/dist/filepond-plugin-image-preview.js"></script>


</head>

<body class="g-sidenav-show">

   <?php echo $__env->make('layouts.inc.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

   <main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg ">
      <?php echo $__env->make("layouts.inc.admin.adminnav", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <div class="container-fluid py-4">
         <?php echo $__env->yieldContent('content'); ?>

         <?php echo $__env->make("layouts.inc.admin.adminfooter", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>

   </main>


   <!-- Scripts -->
   <script src="<?php echo e(asset('admin/js/popper.min.js')); ?>" defer></script>
   <script src="<?php echo e(asset('admin/js/bootstrap.min.js')); ?>" defer></script>
   <script src="<?php echo e(asset('admin/js/perfect-scrollbar.min.js')); ?>" defer></script>
   <script src="<?php echo e(asset('admin/js/smooth-scrollbar.min.js')); ?>" defer></script>
   <script src="<?php echo e(asset('admin/js/chartjs.min.js')); ?>" defer></script>



   <!-- Sweet Alert -->
   <script src="<?php echo e(asset('admin/js/sweetalert2.all.min.js')); ?>"></script>
   <?php if(session('status')): ?>
      <script>
         Swal.fire({
            title: 'Message!',
            text: "<?php echo e(session('status')); ?>",
            confirmButtonText: 'Cool'
         })
      </script>
   <?php endif; ?>

   <?php echo $__env->yieldContent('scripts'); ?>

</body>

</html><?php /**PATH /home/rafik/bijouterie/ecommerce/resources/views/layouts/admin.blade.php ENDPATH**/ ?>