<?php $__env->startSection('content'); ?>

<div class="card">
   <div class="card-header">
      <h3>Marques :</h3>
      <hr>
   </div>

   <div class="card-body">
      <table class="table text-center table-bordered table-striped custom-table">
         <thead>
            <tr>
               <th>ID</th>
               <th>Nom</th>
               <th>Action</th>
            </tr>
         </thead>
         <tbody>
            <?php $__currentLoopData = $brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
               <td><?php echo e($item->id); ?></td>
               <td><?php echo e($item->name); ?></td>
               <td>
                  <a href="<?php echo e(url('edit-brand/' . $item->id)); ?>" class="btn btn-info">Edit</a>
                  <a href="<?php echo e(url('delete-brand/' . $item->id)); ?>" class="btn btn-danger">Delete</a>
               </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </tbody>
      </table>
   </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rafik/bijouterie/ecommerce/resources/views/admin/brand/index.blade.php ENDPATH**/ ?>