<?php $__env->startSection('content'); ?>

<div class="card">
   <div class="card-header">
      <h2>Edit Category</h2>
   </div>

   <div class="card-body">
      <form action="<?php echo e(url('update-category/' . $category->id)); ?>" method="POST">
         <?php echo csrf_field(); ?>
         <?php echo method_field('PUT'); ?>
         <div class="row">
            <div class="col-md-6 md-3">
               <label for="name">Name</label>
               <input type="text" name="name" value="<?php echo e($category->name); ?>" id="name" class="form-control border p-2">
            </div>
            <div class="col-md-6 md-3">
               <label for="slug">Slug</label>
               <input type="text" name="slug" value="<?php echo e($category->slug); ?>" id="slug" class="form-control border p-2">
            </div>
            <div class="col-md-12 md-3">
               <label for="desc">Description</label>
               <textarea name="description" rows="3" id='desc' class="form-control border p-2"><?php echo e($category->description); ?></textarea>
            </div>
            <div class="col-md-6 md-3">
               <label for="status">Status</label>
               <input type="checkbox" name="status"  <?php echo e($category->status ? 'checked' : ''); ?> id="status" class="border p-2">
            </div>
            <div class="col-md-6 md-3">
               <label for="popular">Popular</label>
               <input type="checkbox" name="popular" <?php echo e($category->popular ? 'checked' : ''); ?> id="popular" class="border p-2">
            </div>
            <div class="col-md-12 md-3">
               <label for="meta_title">Meta Title</label>
               <input type="text" name="meta_title" value="<?php echo e($category->meta_title); ?>" id="meta_title" class="form-control border p-2">
            </div>
            <div class="col-md-12 md-3">
               <label for="meta_desc">Meta Description</label>
               <textarea name="meta_desc" rows="3" id='meta_desc' class="form-control border p-2"><?php echo e($category->meta_desc); ?></textarea>
            </div>
            <div class="col-md-12 mb-3">
               <label for="meta_keywords">Meta Keywords</label>
               <textarea name="meta_keywords" rows="3" id='meta_keywords' class="form-control border p-2"><?php echo e($category->meta_keywords); ?></textarea>
            </div>

            <div class="col-md-6">
               <input type="file" name="image" class="form-control border p-2">
            </div>
            
            <?php if($category->image): ?>
               <img src="<?php echo e(asset('assets/uploads/category/' . $category->image)); ?>" class='edit-image mb-3' alt="category image"/>
            <?php endif; ?>

            <div class="col-md-6 mb-3">
               <button type="submit" class="btn btn-primary">Submit</button>
            </div>
         </div>
      </form>
   </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rafik/bijouterie/ecommerce/resources/views/admin/category/edit.blade.php ENDPATH**/ ?>