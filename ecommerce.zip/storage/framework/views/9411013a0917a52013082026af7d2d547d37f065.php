<div class="container">
                <div class="row align-items-center">
                    <div class="col-12">
                        <div class="banner_text">
                            <h2>Les Prix <span>(<?php echo e($newestPriceChange); ?>)</span> :</h2>
                              <?php $__currentLoopData = $prices_table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <tr>
                               <div class="price-range">
                                <p><?php echo e($price->name); ?> : </p>
                            <p><span><?php echo e($price->from); ?></span> Da - <span><?php echo e($price->to); ?></span> Da</p>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div><?php /**PATH /home/rafik/bijouterie/ecommerce/resources/views/layouts/inc/frontend/prices.blade.php ENDPATH**/ ?>