<?php $__env->startSection('content'); ?>

<div class="container">
   <div class="row">
      <div class="col-md-12">
         <div class="card">
            <div class="card-header">
               <h3>
                  User Details
                  <a href="<?php echo e(url('users')); ?>" class="btn btn-warning float-end">Back</a>
               </h3>
               <hr>
            </div>
            <div class="card-body">
               <div class="row">
                  <div class="col-md-4 mt-3">
                     <label for="role">Role</label>
                     <div class="p-2 border" id="role"><?php echo e($user->role_as == '0' ? 'User' : 'Admin'); ?></div>
                  </div>
                  <div class="col-md-4 mt-3">
                     <label for="fname">First Name</label>
                     <div class="p-2 border" id="fname"><?php echo e($user->name); ?></div>
                  </div>
                  <div class="col-md-4 mt-3">
                     <label for="lname">Last Name</label>
                     <div class="p-2 border" id="lname"><?php echo e($user->lname); ?></div>
                  </div>
                  <div class="col-md-4 mt-3">
                     <label for="email">Email</label>
                     <div class="p-2 border" id="email"><?php echo e($user->email); ?></div>
                  </div>
                  <div class="col-md-4 mt-3">
                     <label for="phone">Phone Number</label>
                     <div class="p-2 border" id="phone"><?php echo e($user->phone); ?></div>
                  </div>
                  <div class="col-md-4 mt-3">
                     <label for="address1">Address 1</label>
                     <div class="p-2 border" id="address1"><?php echo e($user->address1); ?></div>
                  </div>
                  <div class="col-md-4 mt-3">
                     <label for="address2">Address 2</label>
                     <div class="p-2 border" id="address2"><?php echo e($user->address2); ?></div>
                  </div>
                  <div class="col-md-4 mt-3">
                     <label for="city">City</label>
                     <div class="p-2 border" id="city"><?php echo e($user->city); ?></div>
                  </div>
                  <div class="col-md-4 mt-3">
                     <label for="state">State</label>
                     <div class="p-2 border" id="state"><?php echo e($user->state); ?></div>
                  </div>
                  <div class="col-md-4 mt-3">
                     <label for="country">Country</label>
                     <div class="p-2 border" id="country"><?php echo e($user->country); ?></div>
                  </div>
                  <div class="col-md-4 mt-3">
                     <label for="zipcode">Zip Code</label>
                     <div class="p-2 border" id="zipcode"><?php echo e($user->zipcode); ?></div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rafik/bijouterie/ecommerce/resources/views/admin/users/view.blade.php ENDPATH**/ ?>