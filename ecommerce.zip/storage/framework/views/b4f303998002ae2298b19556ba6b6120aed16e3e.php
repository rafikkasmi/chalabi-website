<?php $__env->startSection('title'); ?>
   Produits
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="py-3 mb-4 shadow-sm bg-warning border-top">
   <div class="container">
      <h6 class="mb-6">
         <a href="<?php echo e(url('products')); ?>">Collections</a> / 
      </h6>
   </div>
</div>

   <div class="py-5">
      <div class="container">
         <div class="row">
            <h2>Produits</h2>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-md-4 col-sm-6 custom-col-5">               
                                          <?php echo $__env->make('layouts.inc.frontend.single-product',['product'=>$product], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

         </div>
         <div class="d-flex justify-content-center">
               <?php echo $products->links(); ?>

            </div>
      </div>
   </div>
<style>
   svg{
      width:50px;
   }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rafik/bijouterie/ecommerce/resources/views/frontend/products/index.blade.php ENDPATH**/ ?>