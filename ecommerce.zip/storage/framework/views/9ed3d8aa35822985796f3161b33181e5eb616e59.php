<!-- Navbar -->

               <div class="container">
                  <div class="row">
                     <div class="col-md-12">
                        <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                           document.getElementById('logout-form').submit();" class="nav-link text-body font-weight-bold px-0 mt-3 text-end">
                           <i class="fa fa-sign-out me-sm-1"></i>
                           <span class="d-sm-inline d-none"><?php echo e(__('Logout')); ?></span>
                        </a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                           <?php echo csrf_field(); ?>
                        </form>
                     </div>
                  </div>
               </div>
            
<!-- End Navbar -->

<?php /**PATH /home/rafik/bijouterie/ecommerce/resources/views/layouts/inc/adminnav.blade.php ENDPATH**/ ?>