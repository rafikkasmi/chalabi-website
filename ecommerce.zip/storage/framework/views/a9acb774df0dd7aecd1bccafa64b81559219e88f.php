<footer class="footer py-4">
   <div class="container">
      <div class="row">
         <div class="col-md-12">
            <div class="copyright text-center">
               
               ©
               <script>
                  document.write(new Date().getFullYear())
               </script>,
               Chalabi Store
            </div>
         </div>
      </div>
   </div>
</footer><?php /**PATH /home/rafik/bijouterie/ecommerce/resources/views/layouts/inc/admin/adminfooter.blade.php ENDPATH**/ ?>