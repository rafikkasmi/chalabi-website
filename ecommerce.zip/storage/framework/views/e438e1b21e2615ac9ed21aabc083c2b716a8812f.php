<?php $__env->startSection('content'); ?>

<div class="card">
   <div class="card-header">
      <h2>Ajouter Marque</h2>
   </div>

   <div class="card-body">
      <form action="<?php echo e(url('insert-brand')); ?>" method="POST" enctype="multipart/form-data">
         <?php echo csrf_field(); ?>
         <div class="row">
            <div class="col-md-6 md-3">
               <label for="name">Nom</label>
               <input type="text" name="name" id="name" class="form-control border p-2">
            </div>
            <div class="col-md-12 mb-3">
               <button type="submit" class="btn btn-primary">Ajouter</button>
            </div>
         </div>
      </form>
   </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rafik/bijouterie/ecommerce/resources/views/admin/brand/add.blade.php ENDPATH**/ ?>