@extends('layouts.admin')

@section('content')

<div class="card">
   <div class="card-body">
      <h1>Obaida Shurbaji</h1>
   </div>
</div>

@endsection